export default {
    uri: 'http://localhost:3000'
}