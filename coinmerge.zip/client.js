import React from 'react';
import { hydrate } from 'react-dom';
import App from './src/App';

hydrate(<App />, document.getElementById('app'));